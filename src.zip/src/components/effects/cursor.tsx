// src/components/effects/cursor.tsx
"use client";

import { useEffect, useRef, useState } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";

export function CustomCursor() {
  const [isPointer, setIsPointer] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const mouseX = useMotionValue(-100);
  const mouseY = useMotionValue(-100);

  // ring lags slightly behind the dot for a "trailing" feel
  const ringX = useSpring(mouseX, { damping: 30, stiffness: 300, mass: 0.5 });
  const ringY = useSpring(mouseY, { damping: 30, stiffness: 300, mass: 0.5 });

  useEffect(() => {
    const move = (e: MouseEvent) => {
      mouseX.set(e.clientX);
      mouseY.set(e.clientY);
      if (!isVisible) setIsVisible(true);

      const target = e.target as HTMLElement;
      setIsPointer(
        !!target.closest("a, button, [role='button'], input, textarea"),
      );
    };
    const leave = () => setIsVisible(false);

    window.addEventListener("mousemove", move);
    document.addEventListener("mouseleave", leave);
    return () => {
      window.removeEventListener("mousemove", move);
      document.removeEventListener("mouseleave", leave);
    };
  }, [mouseX, mouseY, isVisible]);

  return (
    <div className="pointer-events-none fixed inset-0 z-[999] hidden md:block">
      {/* dot: snaps instantly to mouse */}
      <motion.div
        className="fixed left-0 top-0 h-1.5 w-1.5 rounded-full bg-foreground"
        style={{ x: mouseX, y: mouseY, translateX: "-50%", translateY: "-50%" }}
        animate={{ opacity: isVisible ? 1 : 0 }}
      />
      {/* ring: trails behind, expands on hoverable elements */}
      <motion.div
        className="fixed left-0 top-0 rounded-full border border-foreground/40"
        style={{ x: ringX, y: ringY, translateX: "-50%", translateY: "-50%" }}
        animate={{
          width: isPointer ? 56 : 32,
          height: isPointer ? 56 : 32,
          opacity: isVisible ? (isPointer ? 0.6 : 0.3) : 0,
          backgroundColor: isPointer ? "rgba(255,122,26,0.08)" : "transparent",
        }}
        transition={{ duration: 0.25, ease: "easeOut" }}
      />
    </div>
  );
}
